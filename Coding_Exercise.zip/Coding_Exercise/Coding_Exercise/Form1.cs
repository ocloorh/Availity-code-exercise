﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.FileIO;



namespace Coding_Exercise
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string csvFilepath = @"C:\Users\test1\Documents\EnrollmentFiles.csv";
            DataTable csvData = GetDataFromCSVFile(csvFilepath);
            Console.WriteLine("Rows count:" + csvData.Rows.Count);
            Console.ReadLine();
        }

        private static DataTable GetDataFromCSVFile(string csvFilepath)
        {
            DataTable csvData = new DataTable();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csvFilepath))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;

                    //read columns names
                    string[] colFields = csvReader.ReadFields();
                    foreach (string col in colFields)
                    {
                       
                        DataColumn datecol = new DataColumn(col);
                        datecol.AllowDBNull = true;
                        csvData.Columns.Add(datecol);
                        csvData.DefaultView.Sort = "lastName, FirstName ASC";
                     
                    }

                    while (!csvReader.EndOfData)
                    {
                        string[] dataField = csvReader.ReadFields();
                        //assigning empty value as null
                        for(int i = 0; i < dataField.Length; i++)
                        {
                            if(dataField[i] == "")
                            {
                                dataField[i] = null;
                            }
                        }
                        csvData.Rows.Add(dataField);
                    }
                }

            }
            catch(Exception ex)
            {

            }
            return csvData;
        }
    }
}
